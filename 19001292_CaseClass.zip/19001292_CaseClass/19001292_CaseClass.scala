object caseclass extends App {
  val p1 = new Point(3, 4);
  val p2 = new Point(5, 9);
  println(p1)
  println(p2)
  val p3 = p1 + p2
  val p4 = p1.move(1,4)
  println(p3)
  println(p4)
  val p5 = p1.invert()
  println(p5)
  val p6 = p1.distance(p2)
  println(p6)
}

case class Point(x:Int, y:Int){
  //def x:Int = a;
  //def y:Int = b;

  def +(that:Point) = Point(this.x+that.x, this.y+that.y)
  def move(dx:Int, dy:Int) = Point(this.x+dx, this.y+dy)
  def distance(that:Point) = Point(Math.abs(this.x-that.x), Math.abs(this.y-that.y))
  def invert() = Point(this.y, this.x)
}
